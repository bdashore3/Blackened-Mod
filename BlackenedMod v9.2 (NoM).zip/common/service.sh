# This script will be executed in late_start service mode
# More info in the main Magisk thread
sh '02BlackenedMod.sh'
sh '03KingKernel.sh'
sh 'Zipalign_sqlite.sh'
